package com.hcl.hackathon.fullstack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
// import required classes.

@SpringBootApplication
@RestController
public class FullStackApplication {

	@RequestMapping(value="/" , method = RequestMethod.GET, produces = "application/json")
	@ResponseBody	
	public HTTPEntity<String> returnPingResponse(){
		HTTPHeaders headers = new HTTPHeaders();
		headers.add(HTTPHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		JSONObject responseJson = new JSONObject();
		responseJson.put("pingResult", "Service Responding");
		
		return HTTPEntity<String>(responseJson.toString,headers);
	}
	
	
	public static void main(String[] args) {
		SpringApplication.run(FullStackApplication.class, args);
	}
}
